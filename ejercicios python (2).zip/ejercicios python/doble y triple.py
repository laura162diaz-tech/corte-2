def doble_y_triple():
    n1 = float(input('Ingrese el valor del numero: '))
    do = n1 * 2
    print(f'El doble de su numero es {do}')
    tri = n1 * 3
    print(f'El triple de su numero es {tri}')

# Ejecutar función
doble_y_triple()