def promedio_aritmetico():
    n1 = float(input('Ingrese el primer numero: '))
    n2 = float(input('Ingrese el segundo numero: '))
    n3 = float(input('Ingrese el tercer numero: '))
    promedio = (n1 + n2 + n3) / 3
    print(f'El promedio de sus numeros es de {promedio}')

# Ejecutar función
promedio_aritmetico()