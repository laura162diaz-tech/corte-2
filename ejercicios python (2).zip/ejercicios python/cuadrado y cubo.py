def cuadrado_y_cubo():
    num = float(input('Ingrese el numero: '))
    cuadrado = num**2
    print(f'El valor de su numero al cuadrado es {cuadrado}')
    cubo = num**3
    print(f'El valor de su numero al cubo es {cubo}')

# Ejecutar función
cuadrado_y_cubo()