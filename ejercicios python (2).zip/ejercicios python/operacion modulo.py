def operacion_modulo():
    numero2 = int(input("Ingrese el segundo número: "))
    
    resultado = numero1 % numero2
    
    print(f"El resultado de {numero1} MOD {numero2} es: {resultado}")

# Ejecutar función
operacion_modulo()