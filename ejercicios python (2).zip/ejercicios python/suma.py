def suma():
    n1 = float(input('Ingrese el primer numero: '))
    n2 = float(input('Ingrese el segundo numero: '))
    resultado = n1 + n2
    print(f'El resultado de la suma es {resultado}')

# Ejecutar función
suma()