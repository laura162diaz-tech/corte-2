def capitales():
    pais = input('Ingrese el nombre del pais: ')
    capital = input('Ingrese su capital: ')
    print(f'{capital} es la capital de {pais}')

# Ejecutar función
capitales()