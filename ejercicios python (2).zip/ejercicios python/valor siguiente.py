def valor_siguiente():
    num = float(input('Ingrese su numero: '))
    siguiente = num + 1
    print(f'El siguiente numero del numero ingresado es {siguiente}')

# Ejecutar función
valor_siguiente()